import { clearGitHubToken, setGitHubToken, hasGitHubToken } from "../axiosInstance";

export default {
	hasGitHubToken,
	clearGitHubToken,
	setGitHubToken,
};
